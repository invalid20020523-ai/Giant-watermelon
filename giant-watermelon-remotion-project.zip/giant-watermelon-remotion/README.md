# Гигантский арбуз — Remotion project

Vertical 9:16 Remotion composition, 12 seconds, 24 fps, four storyboard beats based on the supplied reference image.

## Render

Requires Node.js 18+ and an internet connection for the first dependency install.

```bash
npm install
npm run render
```

Output: `out/giant-watermelon.mp4`

Preview interactively with `npm start`.
