import React from 'react';
import {Composition} from 'remotion';
import {GiantWatermelon} from './Video';
export const Root: React.FC = () => <Composition id="GiantWatermelon" component={GiantWatermelon} durationInFrames={288} fps={24} width={1080} height={1920} />;
