import React from 'react';
import {AbsoluteFill, Img, Sequence, interpolate, staticFile, useCurrentFrame, useVideoConfig} from 'remotion';

const scenes = [
  {title:'НЕОЖИДАННАЯ ПОКУПКА', body:'Маленький покупатель пытается сдвинуть гигантский арбуз.', crop:[12,535,232,678]},
  {title:'АРБУЗ БОЛЬШЕ МАШИНЫ', body:'Гигантский арбуз оказывается сильнее любого автомобиля.', crop:[12,680,232,811]},
  {title:'АРБУЗ НЕ ОСТАНОВИТЬ', body:'Он катится по городу, оставляя за собой полный хаос.', crop:[12,814,232,955]},
  {title:'СОЧНЫЙ ФИНАЛ', body:'Арбуз эффектно разлетается на тысячи сочных брызг.', crop:[12,958,232,1095]},
];
const Scene: React.FC<{index:number}> = ({index}) => {
  const frame=useCurrentFrame(); const {fps}=useVideoConfig(); const s=scenes[index];
  const enter=interpolate(frame,[0,12],[0,1],{extrapolateRight:'clamp'});
  const zoom=interpolate(frame,[0,71],[1,1.11]);
  const [x,y,w,h]=s.crop;
  return <AbsoluteFill style={{background:'#071326',color:'white',fontFamily:'Arial, sans-serif',opacity:enter}}>
    <Img src={staticFile('storyboard.png')} style={{position:'absolute',width:1080,height:1920,objectFit:'cover',filter:'blur(28px) brightness(.24)',transform:`scale(${zoom})`}} />
    <AbsoluteFill style={{padding:'70px 42px',justifyContent:'space-between'}}>
      <div style={{border:'4px solid #ffc943',borderRadius:32,padding:'30px 24px',background:'#050a18dd',textAlign:'center'}}>
        <div style={{fontSize:25,color:'#ffcf50',fontWeight:900,letterSpacing:4}}>WHAT THE FLUFF?!</div>
        <div style={{fontSize:48,fontWeight:900,marginTop:20}}>{s.title}</div>
      </div>
      <div style={{height:650,border:'7px solid #ffcd45',borderRadius:28,overflow:'hidden',background:'#172238',boxShadow:'0 20px 70px #0009'}}>
        <Img src={staticFile('storyboard.png')} style={{width:'100%',height:'100%',objectFit:'cover',objectPosition:`${(x/1439)*100}% ${(y/1536)*100}%`,transform:`scale(${zoom})`}} />
      </div>
      <div style={{border:'4px solid #ffc943',borderRadius:32,padding:'34px 38px',background:'#050a18ee'}}>
        <div style={{fontSize:26,color:'#ffcf50',fontWeight:900}}>СЦЕНА {index+1} / 4</div>
        <div style={{fontSize:34,fontWeight:900,marginTop:20}}>{s.title}</div>
        <div style={{fontSize:29,lineHeight:1.35,marginTop:18,color:'#e8edf7'}}>{s.body}</div>
        <div style={{fontSize:22,color:'#ffcf50',fontWeight:900,marginTop:28}}>ГИГАНТСКИЙ АРБУЗ • КОМИЧЕСКИЙ ХАОС</div>
      </div>
    </AbsoluteFill>
  </AbsoluteFill>;
};
export const GiantWatermelon: React.FC = () => <AbsoluteFill>{scenes.map((_,i)=><Sequence key={i} from={i*72} durationInFrames={72}><Scene index={i}/></Sequence>)}</AbsoluteFill>;
